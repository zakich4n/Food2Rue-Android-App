package com.example.myfirstapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ScoreBoardActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.scoreboard);


        recyclerView = findViewById(R.id.recyclerview_score);



        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ScoreAdapter());

    }
}
