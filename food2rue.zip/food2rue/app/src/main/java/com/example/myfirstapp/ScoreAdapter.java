package com.example.myfirstapp;

import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class ScoreAdapter extends RecyclerView.Adapter<ScoreAdapter.ViewHolder>{
    @NonNull
    @Override
    public ScoreAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.scoreboard_line, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ScoreAdapter.ViewHolder viewHolder, int i) {
        viewHolder.setScore(ScoreSingleton.getInstance().score_list.get(i));

        if(i%2 == 0){
            viewHolder.itemView.setBackgroundColor(Color.BLUE);
        } else {
            viewHolder.itemView.setBackgroundColor(Color.CYAN);
        }

    }

    @Override
    public int getItemCount() {
        return ScoreSingleton.getInstance().score_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView textViewNote;
        private TextView textViewDate;

        public ViewHolder( View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.textview_score_date);
            textViewNote = itemView.findViewById(R.id.textview_score_note);
        }

        public void setScore(Score score){
            textViewNote.setText(score.note);
            textViewDate.setText(score.date);
        }
    }
}